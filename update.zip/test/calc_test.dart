import 'package:alum_glass/calc.dart';
import 'package:alum_glass/defaults.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final sys = defaultSystem('t');

  test('شباك درفتين 150 × 120', () {
    final r = compute(sys.templates['w2']!, 150, 120);
    // الكعب = (150 - 20.5) / 2 ، 4 قطع
    expect(r.pieces[0].name, 'الكعب');
    expect(r.pieces[0].length, closeTo(64.75, 1e-9));
    expect(r.pieces[0].qty, 4);
    // المسكة والشنكل = 120 - 4
    expect(r.pieces[1].length, closeTo(116, 1e-9));
    expect(r.pieces[2].length, closeTo(116, 1e-9));
    // البلور = (150 - 17) / 2  ×  (120 - 18)
    expect(r.glass[0].w, closeTo(66.5, 1e-9));
    expect(r.glass[0].h, closeTo(102, 1e-9));
    // مع هذه الأرقام الفرق 1.75 (المتوقع 1.5) و 14- (المتوقع 10.5-) => تنبيهان
    expect(r.warnings.length, 2);
  });

  test('تنبيه المقارنة يختفي لو طابقت القاعدة', () {
    final t = sys.templates['w2']!;
    // نعدّل الخصميات لتطابق القاعدتين: بلور = كعب + 1.5 ، بلور = مسكة - 10.5
    t.glass[0].w.deduction = 17.5;
    t.glass[0].h.deduction = 14.5;
    final r = compute(t, 150, 120);
    expect(r.warnings, isEmpty);
  });

  test('باب 90 × 210', () {
    final r = compute(sys.templates['door']!, 90, 210);
    expect(r.pieces[0].length, closeTo(86.4, 1e-9)); // 90 - 3.6
    expect(r.pieces[1].length, closeTo(207.2, 1e-9)); // 210 - 2.8
    expect(r.glass[0].w, closeTo(76, 1e-9)); // 90 - 14
    expect(r.glass[0].h, closeTo(195.5, 1e-9)); // 210 - 14.5
  });
}

import 'package:flutter/material.dart';
import 'calc.dart';
import 'models.dart';
import 'settings_screen.dart';
import 'store.dart';
import 'widgets.dart';

const _titles = {
  'window': 'قسم الشبابيك',
  'door': 'قسم الأبواب',
  'side': 'قسم الطرف',
  'glass': 'قسم البلور',
};
const _kindNames = {'window': 'شباك', 'door': 'باب', 'side': 'طرف'};

String _keyFor(String kind, int leaves) => kind == 'window' ? 'w$leaves' : kind;

ProfileSystem? _sysById(String id) {
  for (final s in store.systems) {
    if (s.id == id) return s;
  }
  return null;
}

/// شاشة حساب مشتركة الكود ومستقلة الحالة: شبابيك / أبواب / طرف / بلور
class CalcScreen extends StatefulWidget {
  final String kind;
  const CalcScreen({super.key, required this.kind});
  @override
  State<CalcScreen> createState() => _CalcScreenState();
}

class _CalcScreenState extends State<CalcScreen> {
  String? sysId;
  int leaves = 1;
  String glassType = 'w1';
  final wC = TextEditingController();
  final hC = TextEditingController();
  final cntC = TextEditingController(text: '1');

  @override
  void dispose() {
    wC.dispose();
    hC.dispose();
    cntC.dispose();
    super.dispose();
  }

  String get key => widget.kind == 'glass' ? glassType : _keyFor(widget.kind, leaves);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_titles[widget.kind]!)),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          if (store.systems.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('لا توجد قطاعات بعد.\nأضف قطاعاً وحدد خصمياته من الإعدادات.',
                      textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const SettingsScreen())),
                    child: const Text('فتح إعدادات الخصميات'),
                  ),
                ]),
              ),
            );
          }
          final sys = store.systems.firstWhere((s) => s.id == sysId,
              orElse: () => store.systems.first);
          sysId = sys.id;
          final w = parseNum(wC.text), h = parseNum(hC.text);
          final t = sys.templates[key];
          final canAdd = widget.kind != 'glass' &&
              w != null &&
              h != null &&
              w > 0 &&
              h > 0 &&
              t != null &&
              !t.isEmpty;

          return ListView(padding: const EdgeInsets.all(14), children: [
            DropdownButton<String>(
              isExpanded: true,
              value: sys.id,
              items: [
                for (final s in store.systems)
                  DropdownMenuItem(value: s.id, child: Text('القطاع: ${s.name}'))
              ],
              onChanged: (v) => setState(() => sysId = v),
            ),
            if (widget.kind == 'window') ...[
              sectionTitle('عدد الدرف'),
              SegmentedButton<int>(
                segments: [
                  for (final n in [1, 2, 3, 4])
                    ButtonSegment(value: n, label: Text('$n')),
                ],
                selected: {leaves},
                onSelectionChanged: (s) => setState(() => leaves = s.first),
              ),
            ],
            if (widget.kind == 'glass') ...[
              sectionTitle('النوع'),
              DropdownButton<String>(
                isExpanded: true,
                value: glassType,
                items: [
                  for (final k in templateKeys)
                    DropdownMenuItem(value: k, child: Text(templateLabels[k]!))
                ],
                onChanged: (v) => setState(() => glassType = v!),
              ),
            ],
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: numField(wC, 'العرض', onChanged: (_) => setState(() {}))),
              const SizedBox(width: 10),
              Expanded(child: numField(hC, 'الارتفاع', onChanged: (_) => setState(() {}))),
            ]),
            if (widget.kind != 'glass') ...[
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: numField(cntC, 'عدد القطع المتشابهة')),
                const SizedBox(width: 10),
                FilledButton.icon(
                  onPressed: canAdd ? () => _addJob(sys.id, w!, h!) : null,
                  icon: const Icon(Icons.add),
                  label: const Text('أضف للقائمة'),
                ),
              ]),
            ],
            const SizedBox(height: 8),
            ..._results(sys, t, w, h),
            if (widget.kind != 'glass') ..._jobsSection(),
            const SizedBox(height: 40),
          ]);
        },
      ),
    );
  }

  void _addJob(String sid, double w, double h) {
    final c = (parseNum(cntC.text) ?? 1).round().clamp(1, 1000);
    store.jobs.add(JobItem(
        id: store.newId(),
        kind: widget.kind,
        sysId: sid,
        leaves: leaves,
        w: w,
        h: h,
        count: c));
    store.changed();
    wC.clear();
    hC.clear();
    cntC.text = '1';
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أضيف للقائمة'), duration: Duration(seconds: 1)));
  }

  List<Widget> _results(ProfileSystem sys, Template? t, double? w, double? h) {
    if (w == null || h == null) {
      return [
        const Padding(
            padding: EdgeInsets.all(20), child: Center(child: Text('أدخل العرض والارتفاع')))
      ];
    }
    final showProfiles = widget.kind != 'glass';
    final hasProfiles = showProfiles && t != null && t.profiles.isNotEmpty;
    final hasGlass = t != null && t.glass.isNotEmpty;
    if (t == null || (!hasProfiles && !hasGlass)) {
      return [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            'لا توجد قواعد محفوظة لـ "${templateLabels[key]}" في القطاع "${sys.name}".\n'
            'أضفها من: إعدادات الخصميات.',
            textAlign: TextAlign.center,
          ),
        )
      ];
    }
    final res = compute(t, w, h);
    final out = <Widget>[];
    if (hasProfiles) {
      out.add(sectionTitle('قياسات القطاعات'));
      for (final p in res.pieces) {
        out.add(_tile(p.name, fmt(p.length), p.qty, p.note,
            bad: p.length <= 0,
            onAdd: p.length <= 0
                ? null
                : () {
                    store.addCut(CutItem(
                        label: '${sys.name} - ${p.name}', length: p.length, qty: p.qty));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('أضيفت إلى قائمة التقطيع'),
                        duration: Duration(seconds: 1)));
                  }));
      }
    }
    if (hasGlass) {
      out.add(sectionTitle('قياسات الزجاج'));
      for (final g in res.glass) {
        out.add(_tile(g.name, '${fmt(g.w)} × ${fmt(g.h)}', g.qty, g.note,
            bad: g.w <= 0 || g.h <= 0));
      }
      for (final m in res.warnings) {
        out.add(Card(
          color: Colors.orange.shade50,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              const Icon(Icons.warning_amber, color: Colors.orange),
              const SizedBox(width: 8),
              Expanded(child: Text(m)),
            ]),
          ),
        ));
      }
    }
    out.add(Card(
      color: Theme.of(context).colorScheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(
          widget.kind == 'glass'
              ? 'مساحة البلور: ${fmt(res.glassAreaM2)} م²'
              : 'مساحة ${_kindNames[widget.kind]}: ${fmt(w * h / 10000)} م²'
                  '${hasGlass ? "    مساحة البلور: ${fmt(res.glassAreaM2)} م²" : ""}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    ));
    return out;
  }

  Widget _tile(String name, String size, int qty, String note,
          {bool bad = false, VoidCallback? onAdd}) =>
      Card(
        child: ListTile(
          title: Text(name.isEmpty ? '—' : name),
          subtitle: Text(note.isEmpty ? 'العدد: $qty' : 'العدد: $qty\n⚠ $note'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(size,
                textDirection: TextDirection.ltr,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: bad ? Colors.red : null)),
            if (onAdd != null)
              IconButton(
                  tooltip: 'إضافة للتقطيع',
                  icon: const Icon(Icons.playlist_add),
                  onPressed: onAdd),
          ]),
        ),
      );

  // ───────────── قائمة العمل: عدد غير محدود من الشبابيك/الأبواب ─────────────
  List<Widget> _jobsSection() {
    final jobs = store.jobs.where((j) => j.kind == widget.kind).toList();
    if (jobs.isEmpty) return [];
    double totalArea = 0, totalGlass = 0;
    int units = 0;
    final cards = <Widget>[];
    for (var i = 0; i < jobs.length; i++) {
      final j = jobs[i];
      final sys = _sysById(j.sysId);
      final t = sys?.templates[_keyFor(j.kind, j.leaves)];
      final r = t == null ? null : compute(t, j.w, j.h);
      final area = j.w * j.h / 10000 * j.count;
      final garea = r == null ? 0.0 : r.glassAreaM2 * j.count;
      totalArea += area;
      totalGlass += garea;
      units += j.count;
      cards.add(Card(
        child: ExpansionTile(
          title: Text('${_kindNames[j.kind]} ${i + 1}:  ${fmt(j.w)} × ${fmt(j.h)}',
              textDirection: TextDirection.rtl),
          subtitle: Text('${sys?.name ?? "قطاع محذوف"}'
              '${j.kind == "window" ? " • ${j.leaves} درف" : ""} • العدد ${j.count}'),
          children: [
            if (r == null)
              const ListTile(title: Text('لا توجد قواعد لهذا العنصر'))
            else ...[
              for (final p in r.pieces)
                ListTile(
                  dense: true,
                  title: Text(p.name),
                  trailing: Text('${fmt(p.length)}  ×  ${p.qty * j.count}',
                      textDirection: TextDirection.ltr),
                ),
              for (final g in r.glass)
                ListTile(
                  dense: true,
                  title: Text(g.name),
                  trailing: Text('${fmt(g.w)} × ${fmt(g.h)}  ×  ${g.qty * j.count}',
                      textDirection: TextDirection.ltr),
                ),
              for (final m in r.warnings)
                ListTile(
                  dense: true,
                  leading: const Icon(Icons.warning_amber, color: Colors.orange),
                  title: Text(m, style: const TextStyle(fontSize: 12)),
                ),
              ListTile(
                dense: true,
                title: Text(
                    'المساحة: ${fmt(area)} م²   البلور: ${fmt(garea)} م²'),
              ),
            ],
            TextButton.icon(
              onPressed: () {
                store.jobs.remove(j);
                store.changed();
              },
              icon: const Icon(Icons.delete_outline),
              label: const Text('حذف من القائمة'),
            ),
          ],
        ),
      ));
    }
    return [
      sectionTitle('القائمة (${jobs.length})'),
      ...cards,
      Card(
        color: Theme.of(context).colorScheme.primaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('المجموع النهائي',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('عدد القطع: $units'),
            Text('إجمالي المساحة: ${fmt(totalArea)} م²'),
            Text('إجمالي مساحة البلور: ${fmt(totalGlass)} م²'),
          ]),
        ),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => _sendAll(jobs),
        icon: const Icon(Icons.content_cut),
        label: const Text('أرسل كل القطع للأضبان والقطبان'),
      ),
      TextButton.icon(
        onPressed: () {
          store.jobs.removeWhere((j) => j.kind == widget.kind);
          store.changed();
        },
        icon: const Icon(Icons.delete_sweep),
        label: const Text('مسح القائمة'),
      ),
    ];
  }

  void _sendAll(List<JobItem> jobs) {
    var n = 0;
    for (final j in jobs) {
      final sys = _sysById(j.sysId);
      final t = sys?.templates[_keyFor(j.kind, j.leaves)];
      if (sys == null || t == null) continue;
      final r = compute(t, j.w, j.h);
      for (final p in r.pieces) {
        if (p.length <= 0) continue;
        store.cut.add(CutItem(
            label: '${sys.name} - ${p.name}', length: p.length, qty: p.qty * j.count));
        n++;
      }
    }
    store.changed();
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('أضيف $n بند إلى الأضبان والقطبان')));
  }
}

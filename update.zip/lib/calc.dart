import 'models.dart';

class PieceResult {
  final String name;
  final double length;
  final int qty;
  final String note;
  const PieceResult(this.name, this.length, this.qty, this.note);
}

class GlassResult {
  final String name;
  final double w;
  final double h;
  final int qty;
  final String note;
  const GlassResult(this.name, this.w, this.h, this.qty, this.note);
}

class CalcResult {
  final List<PieceResult> pieces;
  final List<GlassResult> glass;
  final List<String> warnings;
  final double glassAreaM2; // بافتراض أن القياسات بالسنتيمتر
  const CalcResult(this.pieces, this.glass, this.warnings, this.glassAreaM2);
}

/// يحسب كل القطع والزجاج من قواعد القالب فقط، بدون أي رقم مضمّن في الكود.
CalcResult compute(Template t, double w, double h) {
  final pieces = <PieceResult>[
    for (final r in t.profiles)
      PieceResult(r.name, r.formula.calc(w, h), r.qty, r.note)
  ];
  final glass = <GlassResult>[
    for (final g in t.glass)
      GlassResult(g.name, g.w.calc(w, h), g.h.calc(w, h), g.qty, g.note)
  ];
  final warnings = <String>[];
  for (final c in t.checks) {
    final gl = glass.where((x) => x.name == c.glass).toList();
    final pc = pieces.where((x) => x.name == c.piece).toList();
    if (gl.isEmpty || pc.isEmpty) continue;
    final actual = (c.dim == 'W' ? gl.first.w : gl.first.h) - pc.first.length;
    if ((actual - c.expected).abs() > 0.01) {
      final dimName = c.dim == 'W' ? 'العرض' : 'الارتفاع';
      warnings.add(
          'تنبيه: فرق ${c.glass} ($dimName) عن ${c.piece} = ${fmt(actual)} '
          'والمتوقع ${fmt(c.expected)} (الموجب = البلور أكبر)');
    }
  }
  var area = 0.0;
  for (final g in glass) {
    area += g.w * g.h / 10000 * g.qty;
  }
  return CalcResult(pieces, glass, warnings, area);
}

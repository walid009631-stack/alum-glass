import 'models.dart';

/// القيم الأولية التي ذكرها المستخدم. تُنشأ مرة واحدة فقط عند أول تشغيل،
/// وكلها قابلة للتعديل من إعدادات الخصميات. أي قيمة غير مذكورة تُترك فارغة.
ProfileSystem defaultSystem(String id) {
  final s = ProfileSystem(id: id, name: 'القطاع الأساسي');

  final w2 = s.of('w2');
  w2.profiles.addAll([
    ProfileRule(
        name: 'الكعب',
        formula: Formula(base: 'W', deduction: 20.5, divisor: 2),
        qty: 4),
    ProfileRule(
        name: 'المسكة',
        formula: Formula(base: 'H', deduction: 4),
        qty: 1,
        note: 'العدد لم يُحدد، عدّله'),
    ProfileRule(
        name: 'الشنكل',
        formula: Formula(base: 'H', deduction: 4),
        qty: 1,
        note: 'العدد لم يُحدد، عدّله'),
  ]);
  w2.glass.add(GlassRule(
      name: 'بلور الشباك',
      w: Formula(base: 'W', deduction: 17, divisor: 2),
      h: Formula(base: 'H', deduction: 18),
      qty: 2,
      note: 'قطعة لكل درفة، تأكد من العدد'));
  w2.checks.addAll([
    GlassCheck(glass: 'بلور الشباك', piece: 'الكعب', dim: 'W', expected: 1.5),
    GlassCheck(glass: 'بلور الشباك', piece: 'المسكة', dim: 'H', expected: -10.5),
  ]);

  final door = s.of('door');
  door.profiles.addAll([
    ProfileRule(
        name: 'عرض الدرفة',
        formula: Formula(base: 'W', deduction: 3.6),
        qty: 1,
        note: 'العدد لم يُحدد، عدّله'),
    ProfileRule(
        name: 'طول الدرفة',
        formula: Formula(base: 'H', deduction: 2.8),
        qty: 1,
        note: 'العدد لم يُحدد، عدّله'),
  ]);
  door.glass.add(GlassRule(
      name: 'بلور الباب',
      w: Formula(base: 'W', deduction: 14),
      h: Formula(base: 'H', deduction: 14.5),
      qty: 1,
      note: 'العدد لم يُحدد، عدّله'));
  return s;
}
